﻿using Microsoft.EntityFrameworkCore;
using System.Net.Http.Json;
using Thoitiet.Caching;
using Thoitiet.Data;
using Thoitiet.DTOs;
using Thoitiet.Interfaces;
using Thoitiet.Models;

public class OpenMeteoClient
{
    private readonly HttpClient
        _httpClient;

    private readonly
        IWeatherConfigService _weatherConfigService;

    public OpenMeteoClient(

        IHttpClientFactory factory,

        IWeatherConfigService
        configService)

    {
        _httpClient =
            factory.CreateClient();

        _weatherConfigService =
            configService;
    }

    public async Task<
    List<WeatherResponse>>

    GetWeather(

    WeatherConfiguration config

    )
    {
        var url =

        "https://api.open-meteo.com/v1/forecast?"

        + $"latitude={config.Latitude}"

        + $"&longitude={config.Longitude}"

        + $"&daily={config.Daily}"

        + $"&hourly={config.Hourly}"

        + $"&current={config.Current}";

        if (
        !string.IsNullOrWhiteSpace(
        config.Timezone
        ))
        {
            url +=
            $"&timezone={config.Timezone}";
        }

        return await
        _httpClient

        .GetFromJsonAsync<
        List<WeatherResponse>
        >(url)

        ?? [];
    }
}
