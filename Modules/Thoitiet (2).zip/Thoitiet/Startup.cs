using Microsoft.Extensions.DependencyInjection;
using OrchardCore.Modules;
using Thoitiet.Caching;
using Thoitiet.Interfaces;
using Thoitiet.Services;

namespace BikeManager.Repair;

public sealed class Startup : StartupBase
{
    public override void ConfigureServices(IServiceCollection services)
    {
        services.AddScoped<IWeatherConfigService, WeatherConfigService>();
        services
    .AddScoped<ICacheService,
        RedisCacheService>();
    }
}

