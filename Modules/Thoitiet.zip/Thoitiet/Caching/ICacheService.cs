﻿namespace Thoitiet.Caching
{
    public interface ICacheService
    {
        Task<T?> GetAsync<T>(
            string key);
        Task SetAsync<T>(

           string key,

           T value,

           TimeSpan ttl

       );
        Task<T> GetOrCreateAsync<T>(
            string key,

            Func<Task<T>> factory,

            TimeSpan ttl);

        Task RemoveAsync(
            string key);
    }
}
