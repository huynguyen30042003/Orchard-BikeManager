﻿using Microsoft.AspNetCore.Mvc;
using Thoitiet.DTOs;
using Thoitiet.Interfaces;
using Thoitiet.Models;

[Route("weather")]
public class WeatherConfigController
    : Controller
{
    private readonly
    IWeatherConfigService
    _configService;

    public WeatherConfigController(

        IWeatherConfigService
        configService)

    {
        _configService =
            configService;
    }

    [HttpPost("config")]
    public async Task<
        IActionResult>

        SaveConfig(

        [FromBody]

        WeatherConfig config)

    {
        await _configService
            .SaveConfig(
            config);

        return Ok();
    }
}