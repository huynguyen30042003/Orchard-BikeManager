﻿using Microsoft.AspNetCore.Mvc;
using Thoitiet.Interfaces;

[ApiController]

[Route("api/v1/weather")]

public class WeatherController
    : ControllerBase
{
    private readonly IWeatherService
        _service;

    public WeatherController(
        IWeatherService service)
    {
        _service =
            service;
    }

    [HttpGet]

    public async Task<IActionResult>
        Get()
    {
        return Ok(
            await _service
            .GetWeather());
    }
}