﻿using Microsoft.AspNetCore.Mvc;

namespace Thoitiet.Controllers
{
    public class WeatherViewController : Controller
    {

        [HttpGet("quan-li-api-thoi-tiet")]
        public IActionResult Index()
        {
            return View("~/Areas/Thoitiet/Views/Thoitiet/Index.cshtml");
        }
    }
}
