﻿using Thoitiet.DTOs;
using Thoitiet.Models;

namespace Thoitiet.Interfaces
{
    public interface IWeatherConfigService
    {
        Task<
        List<WeatherResponse>>
            GetWeather();

        Task Save(
            WeatherConfig config);
    }
}
