﻿using Thoitiet.DTOs;

namespace Thoitiet.Interfaces
{
    public interface IWeatherService
    {
        Task<List<WeatherResponse>>
            GetWeather();
    }
}
