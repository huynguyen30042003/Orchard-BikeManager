﻿namespace Thoitiet.Models
{
    public class WeatherConfig
    {
        public List<string> Latitude { get; set; }
            = [];

        public List<string> Longitude { get; set; }
            = [];

        public List<string> Daily { get; set; }
            = [];

        public List<string> Hourly { get; set; }
            = [];

        public List<string> Current { get; set; }
            = [];

        public string? Timezone { get; set; }
    }
}
