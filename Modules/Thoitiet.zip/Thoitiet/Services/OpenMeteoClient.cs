﻿using System.Net.Http.Json;
using Thoitiet.DTOs;
using Thoitiet.Interfaces;

public class OpenMeteoClient
{
    private readonly HttpClient
        _httpClient;

    private readonly
        IWeatherConfigService
        _configService;

    private static int
        _counter;

    public OpenMeteoClient(

        IHttpClientFactory factory,

        IWeatherConfigService
        configService)

    {
        _httpClient =
            factory.CreateClient();

        _configService =
            configService;
    }

    public async Task<
        List<WeatherResponse>>
        GetWeather()
    {
        var count =
            Interlocked
            .Increment(
            ref _counter);

        Console.WriteLine(

        $"OpenMeteo Call {count}"

        );

        var config =

            await _configService
            .GetConfig();

        if (!config.Latitude.Any())
        {
            return [];
        }

        var url =

        "https://api.open-meteo.com/v1/forecast?"

        + $"latitude={string.Join(",", config.Latitude)}"

        + $"&longitude={string.Join(",", config.Longitude)}"

        + $"&daily={string.Join(",", config.Daily)}"

        + $"&hourly={string.Join(",", config.Hourly)}"

        + $"&current={string.Join(",", config.Current)}";

        if (!string.IsNullOrWhiteSpace(
            config.Timezone))
        {
            url +=

            $"&timezone={Uri.EscapeDataString(

            config.Timezone

            )}";
        }

        Console.WriteLine(url);

        return await _httpClient

            .GetFromJsonAsync<
            List<WeatherResponse>>

            (url)

            ?? [];
    }
}

//using System.Diagnostics.Metrics;
//using System.Net.Http.Json;
//using Thoitiet.DTOs;

//public class OpenMeteoClient
//{
//    private readonly HttpClient
//        _httpClient;
//    private static int _counter;
//    public OpenMeteoClient(
//        IHttpClientFactory factory)
//    {
//        _httpClient =
//            factory.CreateClient();
//    }

//    public async Task<
//        List<WeatherResponse>>
//        GetWeather()
//    {
//        var count =
//             Interlocked.Increment(
//             ref _counter);

//        Console.WriteLine(
//            $"OpenMeteo Call {count}");
//        var url =
//        "https://api.open-meteo.com/v1/forecast?" +

//        "latitude=16.4619,16.5254,16.5832,16.5667,16.4218,16.2723,16.4391" +

//        "&daily=temperature_2m_max,temperature_2m_min,weather_code,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,daylight_duration,sunshine_duration,uv_index_max,uv_index_clear_sky_max,rain_sum,snowfall_sum,showers_sum,precipitation_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant,shortwave_radiation_sum,et0_fao_evapotranspiration" +

//        "&longitude=107.5955,107.4755,107.3644,107.5167,107.64,107.2339,107.7144" +

//        "&hourly=temperature_2m,relative_humidity_2m,dew_point_2m,apparent_temperature,precipitation,precipitation_probability,rain,snowfall,showers,snow_depth,weather_code,pressure_msl,surface_pressure,cloud_cover,cloud_cover_low,cloud_cover_mid,cloud_cover_high,evapotranspiration,visibility,et0_fao_evapotranspiration,vapour_pressure_deficit,wind_speed_10m,wind_speed_80m,wind_speed_120m,wind_speed_180m,wind_direction_10m,wind_direction_80m,wind_direction_120m,wind_gusts_10m,wind_direction_180m,temperature_80m,temperature_120m,temperature_180m,soil_temperature_0cm,soil_temperature_6cm,soil_temperature_18cm,soil_moisture_0_to_1cm,soil_temperature_54cm,soil_moisture_1_to_3cm,soil_moisture_3_to_9cm,soil_moisture_9_to_27cm,soil_moisture_27_to_81cm" +

//        "&current=rain,temperature_2m,wind_speed_10m,relative_humidity_2m,precipitation,wind_direction_10m,wind_gusts_10m,weather_code,cloud_cover,pressure_msl,showers,snowfall,surface_pressure,is_day,apparent_temperature" +

//        "&timezone=Asia%2FBangkok";

//        return await _httpClient
//            .GetFromJsonAsync<
//            List<WeatherResponse>>
//            (url)

//            ?? [];
//    }
//}