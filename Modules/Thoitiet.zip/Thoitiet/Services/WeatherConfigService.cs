﻿namespace Thoitiet.Services
{
    using BikeManagerV3.Repair.Data;
    using Microsoft.EntityFrameworkCore;
    using Thoitiet.Caching;
    using Thoitiet.DTOs;
    using Thoitiet.Interfaces;
    using Thoitiet.Models;

    public class WeatherConfigService
        : IWeatherConfigService
    {
        private readonly ICacheService
            _cache;
        private readonly ThoiTietDbContext
            _dbContext;
        private readonly OpenMeteoClient
        _openMeteoClient;

        public WeatherConfigService(ThoiTietDbContext dbContext,
            ICacheService cache,
            OpenMeteoClient
        openMeteoClient)
        {
            _cache = cache;
            _dbContext = dbContext;
            _openMeteoClient = openMeteoClient;
        }

        public async Task Save(
            WeatherConfig dto)
        {
            var entity =
                new WeatherConfiguration
                {
                    Latitude =
                        string.Join(
                        ",",
                        dto.Latitude),

                    Longitude =
                        string.Join(
                        ",",
                        dto.Longitude),

                    Daily =
                        string.Join(
                        ",",
                        dto.Daily),

                    Hourly =
                        string.Join(
                        ",",
                        dto.Hourly),

                    Current =
                        string.Join(
                        ",",
                        dto.Current),

                    Timezone =
                        dto.Timezone,

                    CreatedAt =
                        DateTime.UtcNow,

                    UpdatedAt =
                        DateTime.UtcNow
                };

            _dbContext
                .WeatherConfigurations
                .Add(entity);

            await _dbContext
                .SaveChangesAsync();
        }

        public async Task<
        List<WeatherResponse>>

        GetWeather()
        {
            var config =

                await _dbContext
                .WeatherConfigurations

                .OrderByDescending(

                x => x.UpdatedAt

                )

                .FirstAsync();

            var cacheKey =

            $"weather:{config.Id}";

            return await _cache
                .GetOrCreateAsync(

                cacheKey,

                async () =>
                {
                    return await

                    _openMeteoClient

                    .GetWeather(config);

                },

                TimeSpan
                .FromMinutes(15)

            );
        }
    }
}
