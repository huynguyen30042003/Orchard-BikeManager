﻿using Thoitiet.Caching;
using Thoitiet.DTOs;
using Thoitiet.Interfaces;

public class WeatherService
    : IWeatherService
{
    private readonly ICacheService
        _cache;

    private readonly OpenMeteoClient
        _openMeteoClient;

    public WeatherService(
        ICacheService cache,

        OpenMeteoClient openMeteoClient)
    {
        _cache = cache;

        _openMeteoClient =
            openMeteoClient;
    }

    public async Task<
        List<WeatherResponse>>
        GetWeather()
    {
        return await _cache
            .GetOrCreateAsync(

            "weather:hue",

            async () =>
            {
                Console.WriteLine(
                    "Call OpenMeteo");

                return await
                    _openMeteoClient
                    .GetWeather();
            },

            TimeSpan
            .FromMinutes(15)
        );
    }


}