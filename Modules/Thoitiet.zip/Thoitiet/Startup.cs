using Microsoft.Extensions.DependencyInjection;
using OrchardCore.Modules;
using Thoitiet.Interfaces;

namespace BikeManager.Repair;

public sealed class Startup : StartupBase
{
    public override void ConfigureServices(IServiceCollection services)
    {
        services.AddScoped<IWeatherService, WeatherService>();
    }
}

